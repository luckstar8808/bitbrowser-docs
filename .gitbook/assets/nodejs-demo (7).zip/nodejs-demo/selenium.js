const { Builder } = require('selenium-webdriver')
const chrome = require('selenium-webdriver/chrome')
const { openBrowser } = require('./request')

main()

async function main() {
  const openRes = await openBrowser('2c9c29a2801851fe01801c44eb0f0033')
  if (openRes.success) {
    let options = new chrome.Options()
    options.options_['debuggerAddress'] = openRes.data.http
    let driver = await new Builder().forBrowser('chrome').setChromeOptions(options).build()

    await driver.get('https://www.baidu.com')
  }
}
