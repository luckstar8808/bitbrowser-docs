const axios = require('axios').default

const baseURL = 'http://127.0.0.1:51997'

const request = axios.create({
  baseURL,
  timeout: 0
})

request.interceptors.response.use(
  response => {
    if (response.status === 200) {
      return response.data
    } else {
      console.log('请求失败，检查网络')
    }
  },
  error => {
    console.error('请求失败了')
    return Promise.reject(error.message)
  }
)

/**
 * @description 打开浏览器并返回wspoint
 * @returns {Promise} Promise<any>
 * @param {String} id
 */
function openBrowser(id) {
  return request({ method: 'post', url: '/browser/open', data: { id } })
}

/**
 * @description 关闭浏览器
 * @param {String} id
 * @returns {Promise}
 */
function closeBrowser(id) {
  return request({ method: 'post', url: '/browser/close', data: { id } })
}

/**
 * @description 创建/修改浏览器，传id是修改，不传id是创建
 * @param {Object} data
 * @returns {Promise}
 */
function updateBrowser(data) {
  return request({ method: 'post', url: '/browser/update', data })
}

/**
 * @description 删除浏览器
 * @param {String} id
 * @returns {Promise}
 */
function deleteBrowser(id) {
  return request({ method: 'post', url: '/browser/delete', data: { id } })
}

/**
 * @description 获取浏览器详情
 * @param {String} id
 * @returns {Promise}
 * */
function getBrowserDetail(id) {
  return request({ method: 'post', url: '/browser/detail', data: { id } })
}

/**
 * @description 分组list
 * @param {Number} page 从0开始
 * @param {Number} pageSize 例如10
 * @returns {Promise}
 * */
function getGroupList(page, pageSize) {
  return request({ method: 'post', url: '/group/list', data: { page, pageSize } })
}

/**
 * @description 添加分组
 * @param {String} groupName
 * @param {Number} sortNum
 * @returns {Promise}
 * */
function addGroup(groupName, sortNum) {
  return request({ method: 'post', url: '/group/add', data: { groupName, sortNum } })
}

/**
 * @description 修改分组
 * @param {String} id
 * @param {String} groupName
 * @param {Number} sortNum
 * @returns {Promise}
 * */
function editGroup(id, groupName, sortNum) {
  return request({ method: 'post', url: '/group/edit', data: { id, groupName, sortNum } })
}

/**
 * @description 删除分组
 * @param {String} id
 * @returns {Promise}
 * */
function deleteGroup(id) {
  return request({ method: 'post', url: '/group/delete', data: { id } })
}

/**
 * @description 分组详情
 * @param {String} id
 * */
function getGroupDetail(id) {
  return request({ method: 'post', url: '/group/detail', data: { id } })
}

module.exports = {
  openBrowser,
  closeBrowser,
  updateBrowser,
  deleteBrowser,
  getBrowserDetail,
  addGroup,
  editGroup,
  deleteGroup,
  getGroupDetail,
  getGroupList,
  request
}
