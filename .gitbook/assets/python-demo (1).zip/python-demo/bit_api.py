import requests,time,random,fileinput

#https://doc.bitbrowser.cn/api-jie-kou-wen-dang/liu-lan-qi-jie-kou


s = requests.session()
url = "http://127.0.0.1:10000"

def bit_create():
    headers = { #'id': '2c9c29a2801851fe01801d5c64c600b2', # 有值时为修改，无值是添加
                # 'groupId': '2c996b378054663b01805a69f0344410', # 群组ID，绑定群组时传入，如果登录的是子账号，则必须赋值，否则会自动分配到主账户下面去
                'platform': 'https://www.google.com', # 账号平台
                'platformIcon': 'google', # 取账号平台的 hostname 或者设置为other
                'url': '', # 打开的url，多个用,分开
                'name': f'google', # 窗口名称
                'remark': '', # 备注
                'userName': '', #用户账号
                'password': '', #用户密码
                'cookie': '', # cookie
                'proxyMethod': 2, # 代理类型 1平台 2自定义
                # 'agentId': '', # proxyMethod为1时，平台代理IP的id
                'proxyType': 'socks5', # 自定义代理类型 ['noproxy', 'http', 'https', 'socks5', '911s5']
                'host': '127.0.0.1', # 代理主机
                'port': '20045', # 代理端口
                # 'proxyUserName': '', # 代理账号
                # 'proxyPassword': '', # 代理密码
                # 'ip': '', # 911 s5 ip
                # 'country': '', # 911 s5 国家地区
                # 'province': '', # 911 s5 州/省
                # 'city': '', # 911 s5城市
                "browserFingerPrint":{"ostype":"PC",# 操作系统平台 PC|Android
                                      'os':'Win64',# Win64|Win32|Linux i686|Linux armv7l|MacIntel
                                      'version': '', #浏览器版本[77,78,...,96]
                                      'userAgent': '', # 不填的话会自动生成
                                      'isIpCreateTimeZone': 'true', # 基于IP生成对应的时区
                                      # 'timeZone': '', # isIpCreateTimeZone为false的时候，从提供的时区列表中随机一个
                                      'webRTC': '0', # webrtc 0(替换)|1(允许)|2(禁止)
                                      'position': '0', # 地理位置 0(询问)|1(允许)|2(禁止)
                                      'isIpCreatePosition': 'true', # 基于IP生成对应的地理位置
                                      # 'lat': '', # 经度 isIpCreatePosition为false时填写
                                      # 'lng': '', # 纬度 isIpCreatePosition为false时填写
                                      # 'precisionData': '', # 精度米 isIpCreatePosition为false时填写
                                      'isIpCreateLanguage': 'true', # 基于IP生成对应的国家语言
                                      # 'languages': '', # isIpCreateLanguage为false，则需要填写语言，从提供的语言列表中选一个值
                                      'resolutionType': '1', # 分辨率 0(跟随电脑)|1(自定义)
                                      'resolution': f'1920 x 1080', # 自定义时分辨率值 1920 x 1080 | 1920 x 1080 | 800 x 600 | ...
                                      'fontType': '2', # 字体 0(系统默认) | 1(自定义) | 2(随机匹配)
                                      # 'font': '', # fontType非系统默认时，可以随机从字体列表中随机取一些，逗号分隔传入
                                      'canvas': '0', # 0(随机) | 1(关闭)
                                      'webGL': '0', # webGL图像 0(随机) | 1(关闭)
                                      'webGLMeta': '0', # webGL元数据 0(自定义) | 1(关闭)
                                      'webGLManufacturer': '', # webGL厂商，从提供的厂商列表中随机选一个
                                      'webGLRender': '', # webGL渲染，从提供的渲染数据list中随机选一个
                                      'audioContext': '0', # Audio 0(随机) | 1(关闭)
                                      'mediaDevice': '0', # Media 0(随机) | 1(关闭)
                                      'hardwareConcurrency': f'8', # CPU核心数
                                      'deviceMemory': f'8', #设备内存
                                      'doNotTrack': '1', # 0(开启) | 1(关闭)
                                      'colorDepth': f'48', # 颜色深度 [48,32, 30, 24, 18, 16, ...] 随机一个颜色深度值
                            }
               }

    a = s.post(f"{url}/browser/update",json=headers).json()
    b = a['data']['id']
    print(b)
    return b


def bit_getws():
    headers = {'id':f'{bit_create()}'}
    a = s.post(f"{url}/browser/open",json=headers).json()
    print(a)
    print(a['data']['http'])
    return a['data']['http']




def bit_stop(id):
    headers = {'id': f'{id}'}
    s.post(f"{url}/browser/close", json=headers).json()


def bit_delete(id):
    headers = {'id': f'{id}'}
    print(s.post(f"{url}/browser/delete", json=headers).json())





if __name__ == '__main__':
    bit_create()
