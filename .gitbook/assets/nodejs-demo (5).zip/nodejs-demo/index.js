const {
  openBrowser,
  closeBrowser,
  updateBrowser,
  deleteBrowser,
  getBrowserDetail,
  addGroup,
  editGroup,
  deleteGroup,
  getGroupDetail,
  getGroupList
} = require('./request')
const puppeteer = require('puppeteer')

main()
// getBrowsers()

// puppeteer 连接
async function main() {
  // 添加群组
  const res = await addGroup('测试群组顶顶顶顶', 0)
  // 获取到群组id
  const groupId = res.data.id
  console.log('群组创建成功，群组id ===>>> ', groupId)
  // 创建浏览器
  const browserRes = await updateBrowser({
    // id: '2c9c29a2801851fe01801d5c64c600b2', // 有值时为修改，无值是添加
    groupId: groupId, // 群组ID，绑定群组时传入，如果登录的是子账号，则必须赋值，否则会自动分配到主账户下面去
    platform: 'https://www.facebook.com', // 账号平台
    platformIcon: 'facebook', // 取账号平台的 hostname 或者设置为other
    url: '', // 打开的url，多个用,分开
    name: '测试平台代理IP', // 窗口名称
    remark: '', // 备注
    userName: '', //用户账号
    password: '', //用户密码
    cookie: '', // cookie
    proxyMethod: 2, // 代理类型 1平台 2自定义
    agentId: '', // proxyMethod为1时，平台代理IP的id
    proxyType: 'noproxy', // 自定义代理类型 ['noproxy', 'http', 'https', 'socks5', '911s5']
    host: '', // 代理主机
    port: '', // 代理端口
    proxyUserName: '', // 代理账号
    proxyPassword: '', // 代理密码
    ip: '', // 911 s5 ip
    country: '', // 911 s5 国家地区
    province: '', // 911 s5 州/省
    city: '', // 911 s5城市
    // 指纹对象
    browserFingerPrint: {
      ostype: 'PC', // 操作系统平台 PC|Android
      os: 'Win64', // Win64|Win32|Linux i686|Linux armv7l|MacIntel
      version: '', //浏览器版本[77,78,...,96]
      userAgent: '', // 不填的话会自动生成
      isIpCreateTimeZone: true, // 基于IP生成对应的时区
      timeZone: '', // isIpCreateTimeZone为false的时候，从提供的时区列表中随机一个
      webRTC: '0', // webrtc 0(替换)|1(允许)|2(禁止)
      position: '1', // 地理位置 0(询问)|1(允许)|2(禁止)
      isIpCreatePosition: true, // 基于IP生成对应的地理位置
      lat: '', // 经度 isIpCreatePosition为false时填写
      lng: '', // 纬度 isIpCreatePosition为false时填写
      precisionData: '', // 精度米 isIpCreatePosition为false时填写
      isIpCreateLanguage: true, // 基于IP生成对应的国家语言
      isIpCreateDisplayLanguage: false, // 显示语言默认不跟随IP
      displayLanguages: '', // 默认系统
      languages: '', // isIpCreateLanguage为false，则需要填写语言，从提供的语言列表中选一个值
      resolutionType: '0', // 分辨率 0(跟随电脑)|1(自定义)
      resolution: '', // 自定义时分辨率值 1920 x 1080 | 1920 x 1080 | 800 x 600 | ...
      fontType: '0', // 字体 0(系统默认) | 1(自定义) | 2(随机匹配)
      font: '', // fontType非系统默认时，可以随机从字体列表中随机取一些，逗号分隔传入
      canvas: '0', // 0(随机) | 1(关闭)
      webGL: '0', // webGL图像 0(随机) | 1(关闭)
      webGLMeta: '0', // webGL元数据 0(自定义) | 1(关闭)
      webGLManufacturer: '', // webGL厂商，从提供的厂商列表中随机选一个
      webGLRender: '', // webGL渲染，从提供的渲染数据list中随机选一个
      audioContext: '0', // Audio 0(随机) | 1(关闭)
      mediaDevice: '0', // Media 0(随机) | 1(关闭)
      hardwareConcurrency: '4', // CPU核心数
      deviceMemory: '8', //设备内存
      doNotTrack: '1', // 0(开启) | 1(关闭)
      colorDepth: '32', // 颜色深度 [48,32, 30, 24, 18, 16, ...] 随机一个颜色深度值
      openWidth: 1280, // 浏览器窗口宽度
      openHeight: 720 // 浏览器窗口高度
    }
  })
  console.log('浏览器创建成功，id ==>>> ', browserRes.data.id)
  // 打开浏览器
  const openRes = await openBrowser(browserRes.data.id)
  if (openRes.success) {
    try {
      console.log('浏览器已打开')
      // 连接浏览器
      await connect(openRes.data.ws)
      console.log('浏览器已连接')
      await sleep(5000)
      // 关闭浏览器
      await closeBrowser(browserRes.data.id)
      console.log('浏览器关闭了')
      await sleep(5000)
      // 删除浏览器
      await deleteBrowser(browserRes.data.id)
      console.log('浏览器删除了')
      await sleep(5000)
      // 删除group
      await deleteGroup(groupId)
      console.log('分组删除了')
    } catch (err) {
      console.error(err)
    }
  } else {
    console.log('获取wspoint失败了')
  }
}

async function connect(wsEndpoint) {
  try {
    const browser = await puppeteer.connect({
      browserWSEndpoint: wsEndpoint,
      defaultViewport: null
    })
    // 具体业务代码
    const pages = await browser.pages()
    console.log('pages length ===>>> ', pages.length)
    const page = await browser.newPage()
    await page.goto('https://www.baidu.com')
    console.log('new page opened.')
    await sleep(5000)
    await page.close()
  } catch (err) {
    console.error(err)
  }
}

async function getBrowsers() {
  const res = await getBrowserList({ page: 1, pageSize: 10 })
  const ids = res.data.list.map(item => item.id)
  console.log(ids)
}

function sleep(timeout) {
  return new Promise(resolve => {
    setTimeout(resolve, timeout)
  })
}
