const { Builder } = require('selenium-webdriver')
const chrome = require('selenium-webdriver/chrome')
const { openBrowser } = require('./request')

main()

async function main() {
  const openRes = await openBrowser({
    id: '2c9c29a2806fd77201806febb0350004',
    args: [],
    loadExtensions: false,
    extractIp: false
  })
  if (openRes.success) {
    let options = new chrome.Options()
    options.options_['debuggerAddress'] = openRes.data.http
    options.options_['prefs'] = { 'profile.default_content_setting_values': { images: 2 } }
    let driver = await new Builder().forBrowser('chrome').setChromeOptions(options).build()

    await driver.get('https://www.baidu.com')
  }
}
