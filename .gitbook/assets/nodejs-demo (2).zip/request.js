const axios = require('axios').default

const baseURL = 'http://127.0.0.1:54345'

const request = axios.create({
  baseURL,
  timeout: 0
})

request.interceptors.response.use(
  response => {
    if (response.status === 200) {
      return response.data
    } else {
      console.log('请求失败，检查网络')
    }
  },
  error => {
    console.error('请求失败了')
    return Promise.reject(error)
  }
)

/**
 * @description 打开浏览器并返回wspoint
 * @returns {Promise<Object>} Promise<any>
 * @param {Object} data
 * @param {String} data.id 窗口id
 * @param {Array} data.args 启动附加参数，数组类型，比如 ["--headless"]
 * @param {Boolean} data.loadExtensions 是否加载扩展
 * @param {Boolean} data.extractIp 是否尝试提取IP
 */
function openBrowser(data) {
  return request({ method: 'post', url: '/browser/open', data })
}

/**
 * @description 关闭浏览器
 * @param {String} id
 * @returns {Promise}
 */
function closeBrowser(id) {
  return request({ method: 'post', url: '/browser/close', data: { id } })
}

/**
 * @description 创建/修改浏览器，传id是修改，不传id是创建
 * @param {Object} data
 * @returns {Promise}
 */
function updateBrowser(data) {
  return request({ method: 'post', url: '/browser/update', data })
}

/**
 * @description 删除浏览器
 * @param {String} id
 * @returns {Promise}
 */
function deleteBrowser(id) {
  return request({ method: 'post', url: '/browser/delete', data: { id } })
}

/**
 * @description 获取浏览器详情
 * @param {String} id
 * @returns {Promise}
 * */
function getBrowserDetail(id) {
  return request({ method: 'post', url: '/browser/detail', data: { id } })
}

/**
 * @description 获取浏览器列表
 * @param {Object} data
 * @param {Number} data.page // 必传
 * @param {Number} data.pageSize // 必传
 * @param {String} data.groupId // 分组ID，非必传
 * @param {String} data.name // 窗口名称，用于模糊查询，非必传
 * @param {String} data.sortProperties // 排序参数，默认序号，seq，非必传
 * @param {String} data.sortDirection // 排序顺序参数，默认desc，可传asc，非必传
 * @returns {Promise}
 * */
function getBrowserList(data) {
  return request({ method: 'post', url: '/browser/list', data })
}

/**
 * @description 分组list
 * @param {Number} page 从0开始
 * @param {Number} pageSize 例如10
 * @returns {Promise}
 * */
function getGroupList(page, pageSize) {
  return request({ method: 'post', url: '/group/list', data: { page, pageSize } })
}

/**
 * @description 添加分组
 * @param {String} groupName
 * @param {Number} sortNum
 * @returns {Promise}
 * */
function addGroup(groupName, sortNum) {
  return request({ method: 'post', url: '/group/add', data: { groupName, sortNum } })
}

/**
 * @description 修改分组
 * @param {String} id
 * @param {String} groupName
 * @param {Number} sortNum
 * @returns {Promise}
 * */
function editGroup(id, groupName, sortNum) {
  return request({ method: 'post', url: '/group/edit', data: { id, groupName, sortNum } })
}

/**
 * @description 删除分组
 * @param {String} id
 * @returns {Promise}
 * */
function deleteGroup(id) {
  return request({ method: 'post', url: '/group/delete', data: { id } })
}

/**
 * @description 分组详情
 * @param {String} id
 * */
function getGroupDetail(id) {
  return request({ method: 'post', url: '/group/detail', data: { id } })
}

function getPids(ids) {
  return request({ url: '/browser/pids', method: 'post', data: { ids } })
}

module.exports = {
  openBrowser,
  closeBrowser,
  updateBrowser,
  deleteBrowser,
  getBrowserDetail,
  addGroup,
  editGroup,
  deleteGroup,
  getGroupDetail,
  getGroupList,
  getBrowserList,
  getPids,
  request
}
