const {
  openBrowser,
  closeBrowser,
  updateBrowser,
  deleteBrowser,
  getBrowserDetail,
  addGroup,
  editGroup,
  deleteGroup,
  getGroupDetail,
  getGroupList,
  getBrowserList,
  getPids
} = require('./request')
const puppeteer = require('puppeteer')

// 主程序
main()

// puppeteer 连接
async function main() {
  try {
    // 创建窗口
    const config = await createBrowser()

    // 打开窗口
    const res = await openBrowser({
      id: config.id,
      args: [],
      loadExtensions: false,
      extractIp: false
    })
    console.log(res)

    // 判断是否打开成功，打开成功则连接浏览器
    if (res.success) {
      await connect(res.data.ws)
    } else {
      console.error('浏览器打开失败')
    }
  } catch (err) {
    console.error(err)
  }
}

// 获取浏览器列表
async function getBrowsers() {
  const res = await getBrowserList({ page: 0, pageSize: 10 })
  const ids = res.data.list.map(item => item.id)
  console.log(ids)
}

async function connect(wsEndpoint) {
  try {
    const browser = await puppeteer.connect({
      browserWSEndpoint: wsEndpoint,
      defaultViewport: null
    })
    // 具体业务代码
    const pages = await browser.pages()
    console.log('pages length ===>>> ', pages.length)

    const page = await browser.newPage()
    await page.goto('https://www.baidu.com')

    console.log('new page opened.')
    await sleep(5000)
    await page.close()

    await sleep(5000)
    await browser.close()
  } catch (err) {
    console.error(err)
  }
}

function sleep(timeout) {
  return new Promise(resolve => {
    setTimeout(resolve, timeout)
  })
}

// 批量打开窗口
// batchOpenBrowser()

async function batchOpenBrowser() {
  for (let i = 0; i < 5; i++) {
    try {
      const config = await createBrowser()
      await sleep(2000)
      const res = await openBrowser(config.id)
      console.log(res)
    } catch (err) {
      console.error(err)
    }
  }
}

// 创建窗口
async function createBrowser() {
  try {
    const res = await updateBrowser({
      id: null, // 有值为修改，没有值为添加
      groupId: null, // 群组ID，绑定群组时传入，如果登录的是子账号，则必须赋值，否则会自动分配到主账户下面去
      platform: 'https://www.facebook.com', //账号平台
      platformIcon: 'facebook',
      url: '', // 打开指定网址，多个用,分开
      name: '', // 窗口名称
      remark: '', // 备注
      userName: '', //用户账号
      password: '', //用户密码
      cookie: '', // cookie
      proxyMethod: 2, // 代理类型，2自定义代理，3提取IP
      proxyType: 'noproxy', // 自定义代理类型 ['noproxy', 'http', 'https', 'socks5', 'lumauto', 'oxylabsauto', 'iphtmlauto']
      host: '', // 代理主机
      port: '', // 代理端口
      proxyUserName: '', // 代理账号
      proxyPassword: '', // 代理密码
      ip: '', // lumauto/oxylabsauto/iphtmlauto 动态IP的 ip
      country: '', // lumauto/oxylabsauto/iphtmlauto 动态IP的 国家地区
      province: '', // lumauto/oxylabsauto/iphtmlauto 动态IP的 州/省
      city: '', // lumauto/oxylabsauto/iphtmlauto 动态IP的 城市
      isIpNoChange: false, // 不用改
      abortImage: false, // 禁止加载图片
      stopWhileNetError: false, // 网络不通停止打开
      dynamicIpUrl: '', // 代理IP提取链接
      dynamicIpChannel: 'rola', // 代理IP厂商 rola | doveip | cloudam | common
      isDynamicIpChangeIp: true, // 是否每次打开都重新提取IP，false则失效才获取
      syncTabs: true, // 同步浏览器已打开的标签页面
      syncCookies: true, // 同步浏览器Cookies，保持登录状态
      syncIndexedDb: false, // 同步IndexedDB数据，一些站点会利用IndexedDB辅助Cookie
      syncBookmarks: false, // 同步浏览器书签
      syncHistory: false, // 同步浏览器访问历史记录
      syncExtensions: false, // 同步该窗口的扩展应用数据，保持扩展应用的登录状态
      syncUserExtensions: false, // 跨窗口同步扩展应用数据
      syncGoogleAccount: false, // 开启后，同一个用户下的不同窗口之间将同步扩展应用数据，保持扩展应用的登录状态
      allowedSignin: true, // 关闭后，无需登录 Chrome 即可登录 Gmail 等 Google 网站（同时不同电脑之间可以同步Gmail等Google网站登录状态）
      syncSessions: false, // 开启后，会同步“历史记录”中“最近关闭的标签页”等网络信息，不建议开启
      clearCacheFilesBeforeLaunch: false, // 启动前清理缓存文件
      clearCookiesBeforeLaunch: false, // 启动前清理cookie
      clearHistoriesBeforeLaunch: false, // 启动前清理历史记录
      randomFingerprint: false, // 每次启动均随机指纹
      workbench: 'chuhai2345', // 浏览器窗口工作台页面 chuhai2345 | localserver
      isValidUsername: false, // 平台，用户名，密码，校验重复，创建时有效
      ipCheckService: 'ip-api', // IP 库，ip-api | ip123 ｜ luminati 其中luminati为luminati专用
      muteAudio: false, // 禁止播放声音
      disableGpu: false, // 关闭GPU硬件加速
      enableBackgroundMode: false, // 关闭浏览器后继续运行应用
      // 指纹对象，需要随机的值，不填即可，如果需要所有指纹都随机，则只传入 browserFingerPrint: {} 空对象即可
      browserFingerPrint: {
        coreVersion: '104', // 内核版本，默认104，可选92
        ostype: 'PC', // 操作系统平台 PC|Android|IOS
        os: 'Win32', // 为navigator.platform值 Win32 | Linux i686 | Linux armv7l | MacIntel，当ostype设置为IOS时，设置os为iPhone，ostype为Android时，设置为 Linux i686 || Linux armv7l
        version: '', //浏览器版本，建议92以上，不填则会从92以上版本随机
        userAgent: '', // ua，不填则自动生成
        isIpCreateTimeZone: true, // 基于IP生成对应的时区
        timeZone: '', // 时区，isIpCreateTimeZone 为false时，参考附录中的时区列表
        timeZoneOffset: 0, // isIpCreateTimeZone 为false时设置，时区偏移量
        webRTC: '0', //webrtc 0替换|1允许|2禁止
        ignoreHttpsErrors: false, // 忽略https证书错误，true|false
        position: '1', //地理位置 0询问|1允许|2禁止
        isIpCreatePosition: true, // 是否基于IP生成对应的地理位置
        lat: '', // 经度 isIpCreatePosition 为false时设置
        lng: '', // 纬度 isIpCreatePosition 为false时设置
        precisionData: '', //精度米 isIpCreatePosition 为false时设置
        isIpCreateLanguage: true, // 是否基于IP生成对应国家的浏览器语言
        languages: '', // isIpCreateLanguage 为false时设置，值参考附录
        isIpCreateDisplayLanguage: false, // 是否基于IP生成对应国家的浏览器界面语言
        displayLanguages: '', // isIpCreateDisplayLanguage 为false时设置，默认为空，即跟随系统，值参考附录
        openWidth: 1280, // 窗口宽度
        openHeight: 720, // 窗口高度
        resolutionType: '0', // 分辨率类型 0跟随电脑 | 1自定义
        resolution: '1920 x 1080', // 自定义分辨率时，具体值
        windowSizeLimit: true, // 分辨率类型为自定义，且ostype为PC时，此项有效，约束窗口最大尺寸不超过分辨率
        devicePixelRatio: 1, // 显示缩放比例，默认1，填写时，建议 1｜1.5|2|2.5|3
        fontType: '2', // 字体生成类型 0系统默认|1自定义|2随机匹配
        font: '', // 自定义或随机匹配时，设置的字体值，值参考附录字体
        canvas: '0', //canvas 0随机｜1关闭
        canvasValue: null, // canvas为0随机时设置， 噪音值 10000 - 1000000
        webGL: '0', //webGL图像，0随机｜1关闭
        webGLValue: null, // webGL为0时，随机噪音值 10000 - 1000000
        webGLMeta: '0', //webgl元数据 0自定义｜1关闭
        webGLManufacturer: '', // webGLMeta 自定义时，webGL厂商值，参考附录
        webGLRender: '', // webGLMeta自定义时，webGL渲染值，参考附录
        audioContext: '0', // audioContext值，0随机｜1关闭
        audioContextValue: null, // audioContext为随机时，噪音值， 1 - 100 ，关闭时默认10
        mediaDevice: '0', // 媒体设备信息，0自定义｜1关闭
        mediaDeviceValue: null, // mediaDevice 噪音值，不填则由系统生成，填值时，参考附录
        speechVoices: '0', // Speech Voices，0随机｜1关闭
        speechVoicesValue: null, // speechVoices为0时，随机时由系统自动生成，自定义时，参考附录
        hardwareConcurrency: '4', // 硬件并发数
        deviceMemory: '8', // 设备内存
        doNotTrack: '1', // doNotTrack 0开启｜1关闭
        clientRectNoiseEnabled: true, // ClientRects true使用相匹配的值代替您真实的ClientRects | false每个浏览器使用当前电脑默认的ClientRects
        clientRectNoiseValue: 0, // clientRectNoiseEnabled开启时随机，值 1 - 999999
        portScanProtect: '0', // 端口扫描保护 0开启｜1关闭
        portWhiteList: '', // 端口扫描保护开启时的白名单，逗号分隔
        colorDepth: '32', // 颜色深度
        deviceInfoEnabled: true, // 自定义设备信息，默认开启
        computerName: '', // deviceInfoEnabled 为true时，设置
        macAddr: '', // deviceInfoEnabled 为true时，设置
        disableSslCipherSuitesFlag: false, // ssl是否禁用特性，默认不禁用，注意开启后自定义设置时，有可能会导致某些网站无法访问
        disableSslCipherSuites: null, // ssl 禁用特性，序列化的ssl特性值，参考附录
        enablePlugins: false, // 是否启用插件指纹
        plugins: '' // enablePlugins为true时，序列化的插件值，插件指纹值参考附录
      }
    })
    return res.data
  } catch (err) {
    console.error(err)
  }
  return null
}
