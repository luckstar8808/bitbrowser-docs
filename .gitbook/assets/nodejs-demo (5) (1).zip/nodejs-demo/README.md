# local api demo

本地调用 api 示例代码，接口以及参数等均已封装，根据业务实际情况，组合调用相关方法即可。

## Install the dependencies

```bash
yarn
```

### Start

```bash
yarn start
```
