from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from bit_api import *


chrome_driver = "C:\\bitbrowser\\chromedriver.exe"
chrome_options = Options()
chrome_options.add_experimental_option("debuggerAddress",bit_getws())
dricer = webdriver.Chrome(chrome_driver, options=chrome_options)
dricer.get('https://www.baidu.com/')

